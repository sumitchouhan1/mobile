package com.cg.capgemini.service;

import com.cg.mra.beans.Account;

public interface IAccountService {
	Account getAccountDetails(String mobileNo);

	double rechargeAccount(String mobileNo, double rechargeAmount);
}
