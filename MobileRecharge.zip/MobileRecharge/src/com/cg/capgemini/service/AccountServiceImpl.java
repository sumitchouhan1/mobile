package com.cg.capgemini.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.dao.IAccountDao;

public class AccountServiceImpl implements IAccountService {
IAccountDao dao=new AccountDaoImpl();
	@Override
	public Account getAccountDetails(String mobileNo) {

		return (dao.getAccountDetails(mobileNo));
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		
		return (dao.rechargeAccount(mobileNo, rechargeAmount));
	}

}
