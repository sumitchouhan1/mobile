package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.capgemini.service.AccountServiceImpl;
import com.cg.capgemini.service.IAccountService;

public class MainUI {
	public static void main(String args[])
	{
		IAccountService obj=new AccountServiceImpl();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("enter 1 for Balance enquiry, 2 for Recharge Account, 3 for Exit" );
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:System.out.println("Enter mobile no");
			String m=sc.next();
			System.out.println(obj.getAccountDetails( m));
			break;
			case 2:System.out.println("Enter mobile no");
			String mob=sc.next();
			System.out.println("enter the amount");
			double amt=sc.nextDouble();
			System.out.println(obj.rechargeAccount(mob, amt));
			break;
			case 3:System.exit(0);
			break;
			}
			
		}
		

}
}
